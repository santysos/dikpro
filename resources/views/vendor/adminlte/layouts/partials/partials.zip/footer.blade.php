<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
       by <a href="http://www.creativeweb.com.ec">Creative Web</a> &copy; 2017 
    </div>
    <!-- Default to the left -->
    <strong><a href="http://www.dikapsa.com">Dikapsa - Soluciones Gráficas</a>.</strong>
</footer>